/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Dao.SearchDao;
import Dao.LogDao;
import Bean.LoginFetch;
import Bean.login;
import Bean.useradd;
import com.sun.corba.se.spi.presentation.rmi.StubAdapter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author abc
 */
public class ContDao {
        
   static LogDao n = new LogDao();
  static SearchDao g = new SearchDao();
    public static Connection getConnection(){  
    Connection con=null;  
    try{  
        Class.forName("com.mysql.jdbc.Driver");  
        con=DriverManager.getConnection("jdbc:mysql://localhost:3306/java_project","root","");  
    }catch(Exception e){System.out.println(e);}  
    return con;  
}  
public static int save(useradd u){  
    int status=0;  
      String  a = n.s;
      System.out.println(a);
    try{  
        Connection con=getConnection();  
        PreparedStatement ps;  
        ps = con.prepareStatement("insert into regist(username,contact,name,email) values(?,?,?,?)");
        ps.setString(1, a);
        ps.setString(2,u.getContact_no());
        ps.setString(3,u.getName());  
        
        ps.setString(4,u.getEmail());  
        
        status=ps.executeUpdate();  
    }catch(Exception e){System.out.println(e);}  
    
    return status;  
}  
public static int update(useradd u){  
    int status=0;  
    try{  
        Connection con=getConnection();  
        PreparedStatement ps=con.prepareStatement(  
"update regist set contact=?,name=?,email=? where id=?");  
        ps.setString(2,u.getName());  
        ps.setString(1, u.getContact_no());
        ps.setString(3,u.getEmail());  
        ps.setInt(4, u.getId());
        status=ps.executeUpdate();  
    }catch(Exception e){System.out.println(e);}  
    return status;  
}  
public static int delete(useradd u){  
    int status=0;  
    try{  
        Connection con=getConnection();  
        PreparedStatement ps=con.prepareStatement("delete from regist where id=?");  
        ps.setInt(1,u.getId());  
        status=ps.executeUpdate();  
    }catch(Exception e){System.out.println(e);}  
  
    return status;  
}  
public static List<useradd> getAllRecords(){  
    List<useradd> list=new ArrayList<useradd>();  
      
    try{  
        Connection con=getConnection();  
        PreparedStatement ps=con.prepareStatement("select * from regist");  
        ResultSet rs=ps.executeQuery();  
        while(rs.next()){  
            useradd u=new useradd();  
            u.setId(rs.getInt("id"));  
            u.setName(rs.getString("name"));  
            u.setContact_no(rs.getString("contact"));
            u.setEmail(rs.getString("email"));  
            
            list.add(u);  
            
        }  
    }catch(Exception e){System.out.println(e);}  
    return list;  
}  

public static useradd getRecordById(int id){  
    useradd u=null;  
    try{  
        Connection con=getConnection();  
        PreparedStatement ps=con.prepareStatement("select * from regist where id=?");  
        ps.setInt(1,id);  
        ResultSet rs=ps.executeQuery();  
        while(rs.next()){  
            u=new useradd();  
            u.setId(rs.getInt("id"));  
            u.setName(rs.getString("name"));  
           u.setContact_no(rs.getString("contact"));
            u.setEmail(rs.getString("email"));  
             
        }  
    }catch(Exception e){System.out.println(e);}  
    return u;  
}  

public static List<useradd> getRecordByname(){ 
    List<useradd> list=new ArrayList<useradd>();  
      String a = n.s;
      System.out.println("byname"+a);
    try{  
        Connection con=getConnection();  
        PreparedStatement ps=con.prepareStatement("select * from regist where username= '"+a+"'");  
        
        ResultSet rs=ps.executeQuery();  
        while(rs.next()){  
            useradd u=new useradd();  
         
            u.setId(rs.getInt("id"));  
            u.setName(rs.getString("name"));  
            u.setContact_no(rs.getString("contact"));
            u.setEmail(rs.getString("email"));  
            
            list.add(u);  
            
        }  
    }catch(Exception e){System.out.println(e);}  
    return list;  
             
        
}  

public static List<useradd> getRecordBynamecontact(){ 
    List<useradd> list=new ArrayList<useradd>();  
      String a = n.s;
      String n = g.n;
      
    try{  
        Connection con=getConnection(); 
      
        PreparedStatement ps=con.prepareStatement("select * from regist where username= '"+a+"' AND name='"+n+"'");  
        
        ResultSet rs=ps.executeQuery();  
        while(rs.next()){  
            useradd u=new useradd();  
         
            u.setId(rs.getInt("id"));  
            u.setName(rs.getString("name"));  
            u.setContact_no(rs.getString("contact"));
            u.setEmail(rs.getString("email"));  
            
            list.add(u);  
            
        }  
    }catch(Exception e){System.out.println(e);}  
    return list;  
             
        
}  
}
