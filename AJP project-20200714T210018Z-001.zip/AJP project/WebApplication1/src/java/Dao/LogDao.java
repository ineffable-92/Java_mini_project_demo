/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Bean.LoginFetch;
import Bean.useradd;
//import static Dao.ContDao.getConnection;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import static java.lang.System.out;
import java.security.Principal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.servlet.AsyncContext;
import javax.servlet.DispatcherType;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpUpgradeHandler;
import javax.servlet.http.Part;

/**
 *
 * @author abc
 */
public class  LogDao {
    
   static  String s;
    public static Connection getConnection(){  
    Connection con=null;  
    try{  
        Class.forName("com.mysql.jdbc.Driver");  
        con=DriverManager.getConnection("jdbc:mysql://localhost:3306/java_project","root","");  
    }catch(Exception e){System.out.println(e);}  
    return con;  
}  
    public static int auth(LoginFetch u){  
        
    int status=0;  
    String p = u.getPass();
           s = u.getUname();
  
    try{  
        
       
         Connection con=getConnection();  
        //PreparedStatement ps=con.prepareStatement("select * from signup where username = '"+u+"' AND password = '"+p"'");
        String searchQuery ="select * from signup where username='"+s+ "' AND password='"+p+ "'";
        Statement stmt =con.createStatement();
        
        ResultSet rs = stmt.executeQuery(searchQuery);	
        boolean more = rs.next();
        System.out.println(more);
        if (!more) 
         {
             System.out.println("Sorry, you are not a registered user! Please sign up first");
            status = 0;
     
         } 
        else if(more)
        {
            System.out.println("logged in");
         status=1;
        System.out.println("Here" +s);
        /* HttpSession session = req.getSession();
                   System.out.println("Here after" +s); 
        session.setAttribute("name",u); 
        String nm = (String)session.getAttribute("name");
            System.out.println("Hello" +nm);*/
        }
        
            //out.close();
            
        }
    catch(Exception e){System.out.println(e);}
    
return status;
}
    
}
