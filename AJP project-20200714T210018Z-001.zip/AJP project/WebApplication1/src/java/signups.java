/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author KEYUR NATHANI
 */
public class signups extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
    {
        resp.setContentType("text/html");
        PrintWriter out=resp.getWriter();
        
        
        String fname=req.getParameter( "fname");
        String lname=req.getParameter("lname");
        
        String s = req.getParameter("uname");
        
        String p = req.getParameter("pass");
        String rp=req.getParameter("rpass");
        try{
            Class.forName("com.mysql.jdbc.Driver");
        Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/java_project","root","");
        Statement st=con.createStatement();
        ResultSet rs=st.executeQuery("select * from signup");
        while(rs.next()){
            if(s.equals(rs.getString(3))){
                
        req.getRequestDispatcher("signuphtml.html").include(req,resp);
        out.println("Username already taken");
        }}
        PreparedStatement stq =con.prepareStatement("insert into signup values(?,?,?,?,?)");
        stq.setString(1,fname);
        stq.setString(2,lname); 
        stq.setString(3,s);
        stq.setString(4,p);
        stq.setString(5,rp);
        int i=stq.executeUpdate();
        if(i==1){
            out.println("Signup Successfull");
            req.getRequestDispatcher("form.jsp").include(req,resp);
        }else{
        req.getRequestDispatcher("signuphtml.html").include(req,resp);
        out.println("Try Again later");}
        
      //    out.println("Signup s")  
        }
        catch(Exception e){System.out.println(e);}
       // String rp=req.getParameter("rpass");
        //try{
        //Class.forName("com.mysql.jdbc.Driver");
        //Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/java_project","java","");
        /*PreparedStatement st =con.prepareStatement("insert into signup values(?,?,?,?,?)");
        st.setString(1,fname);
        st.setString(2,lname); 
        st.setString(3,s);
        st.setString(4,p);
        st.setString(5,rp);
        int i=st.executeUpdate();
        if(i==1){
            out.println("Signup Successfull");
            req.getRequestDispatcher("form.html").include(req,resp);
        }else{
        req.getRequestDispatcher("signuphtml.html").include(req,resp);
        out.println("Try Again later");}
        
      //    out.println("Signup s")  
        }
        catch(Exception e){System.out.println(e);}*/
    }
    }

